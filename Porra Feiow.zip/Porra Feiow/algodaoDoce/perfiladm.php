<?php
    include "cabecalhoadm.php";

    $json = file_get_contents("data_bases/resenha.json");
    $array = json_decode($json, true);



    ?>
<html>
    <head>
        <link rel="stylesheet" href="semantic.css" type="text/css">
        <link rel="stylesheet" type="text/css" href="css/geral.css">
        <script type="text/javascript" src="semantic.js"></script>
        <title>Perfil</title>
    </head>
    <body style="texto-align: center;">

    <h2 class="ui center aligned icon header">
        <i class="circular user icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
               Perfil do Administrador
            </font></font></h2>
    <div class="ui link cards" id="cards" align="center"><?php foreach($array as $jogos): ?>

            <div class="card" id="cardsJogos">
                <div class="image">
                    <a href="<?= $jogos['link'] ?>"><img class="ui fluid image" style="height: 290px; height: 190px" src="data_bases/img/<?= $jogos['img'] ?>"> </a>
                </div>

            </div>
        <?php endforeach ?>

    </body>
</html>
