<?php
?>

<!DOCTYPE html>
<html>

<link rel="stylesheet" type="text/css" href="botoes.css">
<body>
<input style="background-color: red" type="submit" value="Excluir">
<input style="background-color: #808080" type="submit" value="Denunciar">
<input type="submit" value="Editar">
</body>
</html>