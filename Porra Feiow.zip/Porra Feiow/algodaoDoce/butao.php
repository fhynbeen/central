<?php
$json_usuario = file_get_contents("data_bases/usuarios.json");
$array_usuario = json_decode($json_usuario, true);

if ($_GET['acao'] == 'excluir'){
//            echo 'tentou excluir o ' . $_GET['numero'];
    //Percorre a lista, um a um, e atribui os dados do contato a
    //variavel $contato e posicao do contato a variavel $pos
    foreach ($contatos_array as $pos => $contato) {
        if ($contato['nome'] == $_GET['numero']){
            unset( $contatos_array[$pos] );
            break;
        }
    }
    $json = json_encode($contatos_array, JSON_PRETTY_PRINT);
    file_put_contents('contatos.json', $json);
}

?>
<html>
<head>

</head>
<body>
    <form method="get">
<?php foreach ($array_usuario as $pessoa): ?>

    <tr>
        <
        <td><a href="?acao=editar&numero=<?= $pessoa['nome'] ?>">editar</a></td>
        <td><a href="?acao=excluir$nome=<?= $pessoa['nome'] ?>">excluir</a></td>
    </tr>

<?php endforeach; ?>
    </form>
</body>
</html>