<?php

if($_POST['login'] === "admin"){
    logaradm();
}elseif($_POST['login'] != "admin"){
    logar();
}
function logaradm()
{
    $json = file_get_contents("usuarios.json");
    $usuarios = json_decode($json, true);
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    foreach ($usuarios as $usuario) {

        if ($login == $usuario['login'] AND $senha == $usuario['senha']) {

            header("location: ../jogosadm.php");

        }else{
            echo "Insira um login válido";
        }
    }

}
function logar()
{
    $json = file_get_contents("usuarios.json");
    $usuarios = json_decode($json, true);
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    foreach ($usuarios as $usuario) {

        if ($login == $usuario['login'] AND $senha == $usuario['senha']) {

            header("location: ../jogos.php");

        }else{
            echo "Insira um login válido";
        }
    }

}



