<?php
$json = file_get_contents("data_bases/resenha.json");
$array = json_decode($json, true);
$json_usuario = file_get_contents("data_bases/usuarios.json");
$array_usuario = json_decode($json_usuario, true);
foreach($array_usuario as $usuario){
    if($usuario['login'] === "melrulim" ){
        $user = $usuario;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>

    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
    </style>
</head>
<body>

<ul>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="jogos.php">Jogos</a></li>
        <li><a href="recentes.php">Novos</a></li>
        <li><a href="perfil.php" ><img class="ui avatar image" src="data_bases/img/icon.jpeg"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?= $user['nome'] ?></font></font></span></a></li>
        <li><a href="index2.php">Logout</a> </li>
        <div class="right menu" style="padding-left:80% ;padding-right: 10%; border: 5px;">
            <form method="get" action="pesquisa.php">
                <div class="ui icon input">
                    <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                    <i class="circular search link icon"></i>
                </div>
            </form>
        </div>
    </ul>
</ul>

</body>
</html>
