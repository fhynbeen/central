<?php
$teste = file_get_contents("data_bases/resenha.json");
$resenha = json_decode($teste, true);

include "cabecalho.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>
    <style>
        .cards{
            padding-left: 80px;
        }
    </style>

    <meta charset="UTF-8">
    <title>Central Games</title>



</head>
<body>
<br><br>
<div class="ui link cards" id="cards" align="center"><?php foreach($resenha as $jogos): ?>

        <div class="card" id="cardsJogos" style="border-radius: 5px">
            <div class="image">
                <a href="<?= $jogos['link2'] ?>?curtir=curtir"><img class="ui fluid image" style="height: 290px; height: 190px; border-radius: 5px" src="data_bases/img/<?= $jogos['img'] ?>"> </a>
            </div>

        </div>
    <?php endforeach ?>
</div>
</body>
</html>
