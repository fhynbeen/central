<?php
$teste = file_get_contents("data_bases/resenha.json");
$resenha = json_decode($teste, true);

foreach($resenha as $jogoEncontrado){
    if($jogoEncontrado['id'] == 7){
        $jogo = $jogoEncontrado;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>Central Games</title>
</head>
<body>
<?php
include "cabecalho.php";
?>

<div class="ui raised very padded text container segment" id="resenha">
    <h2 class="ui header"><?= $jogo['nomeResenha']?></h2>
    <p><?= $jogo['resenha']; ?></p>
    <div class="image" >
        <img src="data_bases/img/<?= $jogo['img'] ?>" style="width: 500px">
    </div>
    <?php include "curtir.php" ?>
    <?php include "comentario.php"?>
</div>


</body></html>