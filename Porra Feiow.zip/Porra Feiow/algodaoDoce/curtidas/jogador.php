<!--QUESTAO 6-->

<?php 

	//pega o ID_JOGADOR da url
    $id_jogador = $_GET['id_jogador'];

	//abrindo arquivo de jogadores
    $jogadores_json  = file_get_contents('jogadores.json');
    $jogadores_array = json_decode($jogadores_json, true); 

    //abrir arquivo de curtidas
    $curtidas_json  = file_get_contents('curtidas.json');
    $curtidas_array = json_decode($curtidas_json, true); 

    foreach ($jogadores_array as $jogador){

        if($jogador['id_jogador'] == $id_jogador){
            $jogador_encontrado = $jogador;
        }
    }


    //ALGORITMO PARA CURTIR
    if (isset($_GET['acao']) and $_GET['acao'] == "curtir" ) {
    	
    	$curtida = [
	    	"id_usuario" => 1,
	    	"id_jogador" => $id_jogador
	    ];

	    $curtidas_array[] = $curtida;
	    $curtidas_json = json_encode($curtidas_array, JSON_PRETTY_PRINT);
	    file_put_contents("curtidas.json", $curtidas_json);
    }

    //ALGORITMO PARA REMOVER CURTIR
    if (isset($_GET['acao']) and $_GET['acao'] == "remover_curtir" ) {

    	foreach ($curtidas_array as $posicao => $curtida) {
    		
    		if ($id_jogador == $curtida['id_jogador']) {
    			unset($curtidas_array[$posicao]);
    		}
    	}

    	$curtidas_json = json_encode($curtidas_array, JSON_PRETTY_PRINT);
	    file_put_contents("curtidas.json", $curtidas_json);
    }

    //verificar se foi curtida
    $esta_curtido = false;
    foreach ($curtidas_array as $curtida) {
    	if ($id_jogador == $curtida['id_jogador']) {
    		$esta_curtido = true;
    	}
    }

    //var_dump($esta_curtido);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nome do Site</title>

    <!--REPITA A QUESTAO 2-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

<?php require_once 'menu.php'; ?>


<!--QUESTAO 7-->
<div id="conteudo" class="container">
    <div id="jogos" class="row">


        <div class="col-sm-4 mb-5">
            <img src="img/figurinhas/<?= $jogador_encontrado['imagem'] ?>" class="img-fluid" alt="Responsive image">
        </div>

        <div class="col-sm-8 mb-5">

            <ul class="list-group list-group-flush">
                <li class="list-group-item">Nome: <?= $jogador_encontrado['nome'] ?></li>
                <li class="list-group-item">País: <?= $jogador_encontrado['pais'] ?></li>
                <li class="list-group-item">Time: <?= $jogador_encontrado['time'] ?></li>
                <li class="list-group-item">Altura: <?= $jogador_encontrado['altura'] ?></li>
                <li class="list-group-item">Peso: <?= $jogador_encontrado['peso'] ?></li>
                <li class="list-group-item">
                	
                	<?php if($esta_curtido == false): ?>
                		<a href="?id_jogador=<?= $id_jogador ?>&acao=curtir">curtir jogador!</a>
                	<?php else: ?>
                		<a href="?id_jogador=<?= $id_jogador ?>&acao=remover_curtir">remover curtir!</a>

                	<?php endif ?>

                </li>

            </ul>

        </div>

    </div>
</div>


</body>
</html>