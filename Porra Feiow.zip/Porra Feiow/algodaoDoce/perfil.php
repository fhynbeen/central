<?php
include "cabecalho.php";

$json = file_get_contents("data_bases/resenha.json");
$array = json_decode($json, true);
$json_usuario = file_get_contents("data_bases/usuarios.json");
$array_usuario = json_decode($json_usuario, true);
foreach($array_usuario as $usuario){
    if($usuario['login'] != "admin" ){
        $user = $usuario;
    }
}

foreach($array as $jogoEncontrado){
    if($jogoEncontrado['id'] == 10 ){
        $jogo = $jogoEncontrado;
    }
}
foreach($array as $jogo){
    if($jogo['id'] == 15 ){
        $jogotop = $jogo;
    }
}

?>

<html>
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>
    <title>Perfil</title>
    <script>
        $('.special.cards .image').dimmer({
            on: 'hover'
        });
    </script>
</head>
<body>


    <div class="card" style="padding-left: 80%; position: fixed;">
        <div class="card">
            <div class="content">
                <div class="ui small circular rotate left reveal image">
                    <img src="data_bases/img/icon.jpeg" class="visible content">
                    <a href="perfil.php"><img src="data_bases/img/icon.jpeg" class="hidden content"></a>
                </div>
                <div class="content">
                    <h3><?= $user['nome'] ?></h3>
                    <div class="meta">
                        <p><?= $user['email'] ?></p>
                    </div>
                    <a class="ui teal labeled icon button" href="">
                        Editar Perfil
                        <i class="pencil icon"></i>
                    </a></div>
            </div>
        </div></div>
    <h1 style="text-align: center">Minhas Resenhas</h1>

<div class="ui link cards" id="cards" style="padding-left: 30%">

        <div class="card" id="cardsJogos">
            <div class="ui card">

                <div class="image">
                    <img src="data_bases/img/<?= $jogoEncontrado['img']?>" >
                </div>

            </div>
        </div>
    <div class="card" id="cardsJogos">
        <div class="ui card">

            <div class="image">
                <img src="data_bases/img/<?= $jogotop['img']?>" >
            </div>

        </div>
    </div>
</body>
</html>
