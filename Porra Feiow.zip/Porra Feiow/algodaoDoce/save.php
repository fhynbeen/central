<?php


// Pega a requisição post e transforma em JSON.
    $array_usuarios = file_get_contents('data_bases/usuarios.json');
    $array = json_decode($array_usuarios);

    $array[] = $_POST;
    $values = json_encode($array, JSON_PRETTY_PRINT);

// Armazena no final do arquivo os valores recebidos.
    file_put_contents('data_bases/usuarios.json', $values);
    header("location: index2.php");

