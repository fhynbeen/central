<?php

$comentarios = file_get_contents("data_bases/comentario.json");
$array = json_decode($comentarios, true);

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>
</head>
<body>

<div class="ui comments">
    <div class="comment"><?php foreach($array as $bla):?>

        <a class="ui blue ribbon label"><img  src="data_bases/img/icon.jpeg" style="border-radius: 120px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    User 1337
                </font></font></a>

        <div class="content">
            <div class="actions" style="margin-left: 100px">
                <a class="reply active"><?= $bla['comentario'] ?></a>
            </div>

            <hr>

            <?php endforeach; ?>

        </div>
    </div>
</div>


</body>
</html>

