<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>

    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
    </style>
</head>
<body>

<ul>
    <ul>
        <li><a href="index2.php">Home</a></li>
        <li><a href="jogos3.php">Jogos</a></li>
        <li><a href="recentes3.php">Novos</a></li>
        <li><a href="login.php">Login</a> </li>
        <div class="right menu" style="padding-left:80% ;padding-right: 10%; border: 5px;">
            <form method="get" action="pesquisa.php">
                <div class="ui icon input">
                    <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                    <i class="circular search link icon"></i>
                </div>
            </form>
        </div>
    </ul>
</ul>

</body>
</html>
