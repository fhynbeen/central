
<!DOCTYPE html>
<html>
<head>
    <!-- Standard Meta -->
    <meta charset="utf-8" />
    <title>Cadastro</title>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <script type="text/javascript" src="semantic.js">

    </script>
    <style type="text/css">
        body {
            background-image: url(https://images4.alphacoders.com/197/197734.jpg);
        }
        body > .grid {
            height: 100%;
        }

        .column {
            max-width: 450px;
        }
        .ui.stacked.segment{
            width: 350px;

        }
    </style>
</head>
<body>


<div class="ui middle aligned center aligned grid">
    <div class="column">

        <form method="post" action="save.php" ">
            <div class="ui stacked segment">
                <div class="field">
                    <h2 class="ui green header">
                        Central Games
                    </h2>
                    <div class="ui left icon input">
                        <i class="mail icon"></i>
                        <input type="text" id="email" name="email" placeholder="Email" required>
                    </div>
                </div>

                <div class="field">
                    <div class="ui left icon input">
                        <i class="user icon"></i>
                        <input type="text" id="nome" name="nome" placeholder="Nome completo" required>
                    </div>
                </div><div class="field">
                    <div class="ui left icon input">
                        <i class="user icon"></i>
                        <input type="text" id="login" name="login" placeholder="Username" required>
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="lock icon"></i>
                        <input type="password" id="senha" name="senha" placeholder="Senha">
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="lock icon"></i>
                        <input type="password"  id="confirmacaoSenha" name="confirmacaoSenha" placeholder="Confirma senha">
                    </div>
                </div>

                <input type="submit" class="ui button orange" value="Cadastrar"><br>
                <a href="login.php">ou faça Login</a>
                <hr>
                <a href="index.php">Volte para a página inicial.</a>
            </div>



        </form>


    </div>
</div>


</body>

</html>