
<?php
/*A funcao file_get_contents obtem os dados do arquivo contatos.json e
 atribui seu conteudo a variavel $contato_json*/
$contatos_json  = file_get_contents('data_bases/usuarios.json');
/*Transforma o texto da variavel $contatos_json em um array associativo*/
$contatos_array = json_decode($contatos_json, true);
function salvar_contatos_agenda($parametro_array_contatos){
    $json = json_encode($parametro_array_contatos, JSON_PRETTY_PRINT);
    file_put_contents('data_bases/usuarios.json', $json);
}
function buscarContato(){
    //TODO
}
function buscarContatos(){
    //TODO
}
//is set - verifica se existe $_GET['acao'] (na url)
if ( isset($_GET['acao']) ){
    //CADASTRAR
    if ( $_GET['acao'] == 'cadastrar'){
        $novoContato = [
            "name"   => $_POST['campo_nome'],
            "email"  => $_POST['campo_email'],
            "number" => uniqid()
        ];
        //atualiza o array de contatos
        $contatos_array[] = $novoContato;
        //tbm atualiza o arquivo .json
        //$json = json_encode($contatos_array, JSON_PRETTY_PRINT);
        //file_put_contents('contatos.json', $json);
        salvar_contatos_agenda($contatos_array);
    }
    //DELETE
    if ($_GET['acao'] == 'excluir'){
//            echo 'tentou excluir o ' . $_GET['numero'];
        //Percorre a lista, um a um, e atribui os dados do contato a
        //variavel $contato e posicao do contato a variavel $pos
        foreach ($contatos_array as $pos => $contato) {
            if ($contato['nome'] == $_GET['numero']){
                unset( $contatos_array[$pos] );
                break;
            }
        }
        $json = json_encode($contatos_array, JSON_PRETTY_PRINT);
        file_put_contents('contatos.json', $json);
    }
    //UPDATE
    if ($_GET['acao'] == 'editar'){
        echo 'tentou editar o ' . $_GET['numero'];
        foreach ($contatos_array as $contato) {
            if ($_GET['nome'] == $contato['number']){
                $contatoEncontrado = $contato;
                break;
            }
        }
    }//fim do if editar
    if ($_GET['acao'] == 'salvar_contato_editado'){
        foreach ($contatos_array as $pos => $contato){
            if ($_POST['campo_numero'] == $contato['number']){
                $contatos_array[$pos]['nome'] = $_POST['campo_editar_nome'];
                $contatos_array[$pos]['email'] = $_POST['campo_editar_email'];
                break;
            }
        }
        //tbm atualiza o arquivo .json
        $json = json_encode($contatos_array, JSON_PRETTY_PRINT);
        file_put_contents('contatos.json', $json);
    }
}
?>

<h2>Formulario de cadastro</h2>

<form method="post" action="?acao=cadastrar">

    <input type="text" name="campo_nome" placeholder="digite um nome" >
    <input type="text" name="campo_email" placeholder="digite um e-mail"  >

    <input type="submit" value="cadastrar">

</form>



<!--Formulario de editar-->
<form method="post" action="?acao=salvar_contato_editado">

    <input readonly type="hidden" value="<?= @$contatoEncontrado['nome']?>" name="campo_numero">


    <input type="text" value="<?= @$contatoEncontrado['nome']?>" name="campo_editar_nome" placeholder="digite um nome" >
    <input type="text" value="<?= @$contatoEncontrado['email']?>" name="campo_editar_email" placeholder="digite um e-mail"  >

    <input type="submit" value="atualizar">
</form>



<table>

    <tr>
        <td>numero</td>
        <td>nome</td>
        <td>email</td>
        <td>editar</td>
        <td>excluir</td>
    </tr>

    <?php foreach ($contatos_array as $pessoa): ?>

        <tr>
            <td><?= $pessoa['nome'] ?></td>
            <td><?= $pessoa['nome'] ?></td>
            <td><?= $pessoa['email'] ?></td>
            <td><a href="?acao=editar&numero=<?= $pessoa['nome'] ?>">editar</a></td>
            <td><a href="?acao=excluir&numero=<?= $pessoa['nome'] ?>">excluir</a></td>
        </tr>

    <?php endforeach; ?>

</table>




