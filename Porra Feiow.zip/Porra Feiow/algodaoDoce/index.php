<?php
require "cabecalho.php";
?>
    <html>
    <meta charset="utf-8">


    <div class="divisor"></div>
    <div class="divisor"></div>
    <section style= "background-color: #333" style="width: 100%" class="rodape"><center><font size="5%" color="white">Top 5 Jogos Mais Curtidos</center><br></section></font>
    </article>
    <center>


        <br>
        <br>

        <div style="width: 35%">
            <h2>1º Prey</h2>
            <a href="prey.php"><img src="data_bases/img/prey.jpeg" width="5%" height="4%"></a>
        </div>

        <br>
        <div style="width: 35%" style="padding-left: 5%">
            <h2>2º Mass Effect Andromeda</h2>
            <a href="andromeda.php"><img src="data_bases/img/andromeda.jpg" width="5%" height="4%"></a>
        </div>

        <br>
        <div style="width: 35%" style="padding-left: 5%">
            <h2>3º Resident Evil</h2>
            <a href="re7.php"><img src="data_bases/img/re7.jpg" width="5%" height="4%"></a>
        </div>

        <br>
        <div style="width: 35%" style="padding-left: 5%">
            <h2>4º Middle Earth - Shadow Of War</h2>
            <a href="middle.php"><img src="data_bases/img/middle.jpg" width="5%" height="4%"></a>
        </div>

        <br>
        <div style="width: 35%" style="padding-left: 5%">
            <h2>5º Destiny 2</h2>
            <a href="destiny.php"><img src="data_bases/img/destiny_2.jpg" width="5%" height="4%"></a>
        </div>


    </center>





    <div class="divisor"></div>
    <div class="divisor"></div>
    <br>
    <section style= "background-color: #333" style="width: 100%" class="rodape"><center><font size="4.5%" color="white">Leticia e Bruno</center><br></section></font>
    </article>

    </html>
    ?>

<?php
//include("rodape.php");
?>