<?php
$json = file_get_contents('data_bases/resenha.json');
$array_jogos = json_decode($json, true);

$nome = $_GET['pesquisar'];
$jogo_encontrado = null;

foreach ($array_jogos as $jogo){
    if ( strtolower( $jogo['nomeResenha']) == strtolower($nome) ||$jogo['id'] == strtolower($nome) ){
        $jogo_encontrado = $jogo;
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/geral.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>Central Games</title>
</head>
<body>
<?php
include "cabecalhoadm.php";
?>

<div class="ui raised very padded text container segment" id="resenha">
    <h2 class="ui header"><?= $jogo_encontrado['nomeResenha']?></h2>
    <p><?= $jogo_encontrado['resenha']; ?></p>
    <div class="image" >
        <img src="data_bases/img/<?= $jogo_encontrado['img'] ?>" style="width: 500px">
    </div>
</div>


</body></html>